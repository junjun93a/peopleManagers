create trigger "recv_trigB"
  before insert
  on "bydetail"
  for each row
  DECLARE
BEGIN
  SELECT SEQ_T_RECVB.NEXTVAL INTO :new.T_ID FROM DUAL;
END recv_trigB;
/

