create trigger TR_PM12
  before insert
  on P_REWARDANDPUNISH
  for each row
  DECLARE
BEGIN
  SELECT T_PM12.NEXTVAL INTO :NEW.T_ID FROM DUAL;
END TR_PM12;
/

