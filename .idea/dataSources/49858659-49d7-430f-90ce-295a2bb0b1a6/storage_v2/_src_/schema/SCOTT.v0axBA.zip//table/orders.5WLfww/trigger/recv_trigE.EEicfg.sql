create trigger "recv_trigE"
  before insert
  on "orders"
  for each row
  DECLARE
BEGIN
  SELECT SEQ_T_RECVE.NEXTVAL INTO :new.T_ID FROM DUAL;
END recv_trigE;
/

