create trigger "recv_trig"
  before insert
  on "buycar"
  for each row
  DECLARE
BEGIN
  SELECT SEQ_T_RECVA.NEXTVAL INTO :new.T_ID FROM DUAL;
END recv_trig;
/

