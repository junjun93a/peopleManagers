create trigger "recv_trigC"
  before insert
  on "comment"
  for each row
  DECLARE
BEGIN
  SELECT SEQ_T_RECVC.NEXTVAL INTO :new.T_ID FROM DUAL;
END recv_trigC;
/

