create trigger TR_PM10
  before insert
  on P_TRAINDETAIL
  for each row
  DECLARE
BEGIN
  SELECT T_PM10.NEXTVAL INTO :NEW.T_ID FROM DUAL;
END TR_PM10;
/

