create trigger "recv_trigF"
  before insert
  on "realstock"
  for each row
  DECLARE
BEGIN
  SELECT SEQ_T_RECVF.NEXTVAL INTO :new.T_ID FROM DUAL;
END recv_trigF;
/

