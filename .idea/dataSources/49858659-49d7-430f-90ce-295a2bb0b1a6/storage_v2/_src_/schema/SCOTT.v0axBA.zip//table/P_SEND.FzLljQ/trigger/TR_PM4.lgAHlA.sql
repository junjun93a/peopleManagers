create trigger TR_PM4
  before insert
  on P_SEND
  for each row
  DECLARE
BEGIN
  SELECT T_PM4.NEXTVAL INTO :NEW.T_ID FROM DUAL;
END TR_PM4;
/

