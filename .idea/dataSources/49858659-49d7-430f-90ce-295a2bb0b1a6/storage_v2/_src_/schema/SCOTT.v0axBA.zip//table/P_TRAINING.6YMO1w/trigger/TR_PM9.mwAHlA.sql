create trigger TR_PM9
  before insert
  on P_TRAINING
  for each row
  DECLARE
BEGIN
  SELECT T_PM9.NEXTVAL INTO :NEW.T_ID FROM DUAL;
END TR_PM9;
/

