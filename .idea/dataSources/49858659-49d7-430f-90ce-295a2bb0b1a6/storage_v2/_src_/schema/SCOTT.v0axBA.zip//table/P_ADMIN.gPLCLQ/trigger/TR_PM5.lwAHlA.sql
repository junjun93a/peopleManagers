create trigger TR_PM5
  before insert
  on P_ADMIN
  for each row
  DECLARE
BEGIN
  SELECT T_PM5.NEXTVAL INTO :NEW.T_ID FROM DUAL;
END TR_PM5;
/

