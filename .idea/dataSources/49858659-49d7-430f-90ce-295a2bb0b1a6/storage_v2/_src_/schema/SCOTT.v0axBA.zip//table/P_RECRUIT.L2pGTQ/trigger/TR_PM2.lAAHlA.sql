create trigger TR_PM2
  before insert
  on P_RECRUIT
  for each row
  DECLARE
BEGIN
  SELECT T_PM2.NEXTVAL INTO :NEW.T_ID FROM DUAL;
END TR_PM2;
/

