create trigger TR_PM1
  before insert
  on P_VISITOR
  for each row
  DECLARE
BEGIN
  SELECT T_PM1.NEXTVAL INTO :new.T_ID FROM DUAL;
END TR_PM1;
/

