create trigger TR_PM11
  before insert
  on P_ATTENDANCE
  for each row
  DECLARE
BEGIN
  SELECT T_PM11.NEXTVAL INTO :NEW.T_ID FROM DUAL;
END TR_PM11;
/

