create trigger TR_PM3
  before insert
  on P_RESUME
  for each row
  DECLARE
BEGIN
  SELECT T_PM3.NEXTVAL INTO :NEW.T_ID FROM DUAL;
END TR_PM3;
/

