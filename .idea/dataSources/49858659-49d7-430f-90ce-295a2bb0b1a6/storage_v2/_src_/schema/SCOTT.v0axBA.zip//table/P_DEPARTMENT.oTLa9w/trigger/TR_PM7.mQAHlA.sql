create trigger TR_PM7
  before insert
  on P_DEPARTMENT
  for each row
  DECLARE
BEGIN
  SELECT T_PM7.NEXTVAL INTO :NEW.T_ID FROM DUAL;
END TR_PM7;
/

