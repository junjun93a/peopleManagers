create trigger TR_PM6
  before insert
  on P_POSITION
  for each row
  DECLARE
BEGIN
  SELECT T_PM6.NEXTVAL INTO :NEW.T_ID FROM DUAL;
END TR_PM6;
/

