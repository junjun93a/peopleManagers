create trigger "recv_trigD"
  before insert
  on "good"
  for each row
  DECLARE
BEGIN
  SELECT SEQ_T_RECVD.NEXTVAL INTO :new.T_ID FROM DUAL;
END recv_trigD;
/

