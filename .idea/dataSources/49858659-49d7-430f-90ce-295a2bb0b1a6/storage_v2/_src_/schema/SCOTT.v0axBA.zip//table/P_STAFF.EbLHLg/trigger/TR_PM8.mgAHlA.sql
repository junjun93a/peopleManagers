create trigger TR_PM8
  before insert
  on P_STAFF
  for each row
  DECLARE
BEGIN
  SELECT T_PM8.NEXTVAL INTO :NEW.T_ID FROM DUAL;
END TR_PM8;
/

